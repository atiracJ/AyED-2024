﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4_Carita_PixelDreams
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ingrese la cantidad de participantes en el torneo: ");
            int numParticipantes = int.Parse(Console.ReadLine());

            int[] puntajes = new int[numParticipantes];

            for (int i = 0; i < numParticipantes; i++)
            {
                Console.WriteLine($"Ingrese el puntaje del participante" + (i + 1) + ":");
                puntajes[i] = int.Parse(Console.ReadLine());
            }

            Array.Sort(puntajes);
            Array.Reverse(puntajes);

            Console.WriteLine("\nPuntajes ordenados de mayor a menor:");
            for (int i = 0; i < numParticipantes; i++)
            {
                Console.WriteLine($"Puesto" + (i + 1) + ":" + (puntajes[i]) + "puntos");
            }

            Console.WriteLine($"\nPrimer lugar (mayor puntaje):" + (puntajes[0]) + "puntos");
            Console.WriteLine($"Último lugar (menor puntaje):" + (puntajes[numParticipantes - 1]) + "puntos");


            Console.ReadKey();
        }
    }
}
